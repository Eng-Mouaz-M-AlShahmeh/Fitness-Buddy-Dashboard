<?php

return [
    'name' => 'Meal'
];
