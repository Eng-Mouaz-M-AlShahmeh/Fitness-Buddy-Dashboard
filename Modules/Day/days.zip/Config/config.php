<?php

return [
    'name' => 'Day'
];
