<?php

return [
    'name' => 'ResturantCategory'
];
